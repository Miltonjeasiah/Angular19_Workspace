### [coreui-free-angular-admin-template](https://coreui.io/angular/) changelog

---

#### `5.6.15`

- chore(dependencies): cli update to `Angular 21.1.5`
  - `@angular/build` @ "21.1.5" (was "21.1.4")
  - `@angular/cli` @ "21.1.5" (was "21.1.4")
  - `@coreui/angular` @ "5.6.15" (was "5.6.13")
  - `@coreui/angular-chartjs` @ "5.6.15" (was "5.6.13")
  - `@coreui/icons-angular` @ "5.6.15" (was "5.6.13")
  - `jasmine-core` @ "6.1.0" (was "6.0.1")
- chore(dependencies): remove override `ajv` 

---

#### `5.6.13`

- test: migrate from karma to vitest
- chore(dependencies): update to `Angular 21.1.5`
  - `@angular/build` @ "21.1.4" (was "21.1.2")
  - `@angular/cli` @ "21.1.4" (was "21.1.2")
  - `@angular/compiler-cli` @ "21.1.5" (was "21.1.3")
  - `@angular/animations` @ "21.1.5" (was "21.1.3")
  - `@angular/cdk` @ "21.1.5" (was "21.1.3")
  - `@angular/common` @ "21.1.5" (was "21.1.3")
  - `@angular/compiler` @ "21.1.5" (was "21.1.3")
  - `@angular/core` @ "21.1.5" (was "21.1.3")
  - `@angular/forms` @ "21.1.5" (was "21.1.3")
  - `@angular/language-service` @ "21.1.5" (was "21.1.3")
  - `@angular/localize` @ "21.1.5" (was "21.1.3")
  - `@angular/platform-browser` @ "21.1.5" (was "21.1.3")
  - `@angular/platform-browser-dynamic` @ "21.1.5" (was "21.1.3")
  - `@angular/router` @ "21.1.5" (was "21.1.3")
  - `@coreui/angular` @ "5.6.13" (was "5.6.12")
  - `@coreui/angular-chartjs` @ "5.6.13" (was "5.6.12")
  - `@coreui/icons-angular` @ "5.6.13" (was "5.6.12")
  - `zone.js` @ "0.16.1" (was "0.16.0")
  - `@types/node` @ "24.10.13" (was "24.10.10")
- chore(dependencies): `tar` vulnerability https://github.com/advisories/GHSA-83g3-92jg-28cx
- chore(dependencies): `qs` vulnerability https://github.com/advisories/GHSA-w7fw-mjwx-w883
- chore(dependencies): `hono` vulnerability https://github.com/advisories/GHSA-gq3j-xvxp-8hrf
- chore(dependencies): override `ajv` vulnerability https://github.com/advisories/GHSA-2g4f-4pwh-qvx6
- chore(dependencies): override `@modelcontextprotocol/sdk` removed
- chore(dependencies): update jasmine-core & jsdom

---

#### `5.6.12`

- chore(dependencies): update to `Angular 21.1.3`
  - `@angular/compiler-cli` @ "21.1.3" (was "21.1.2")
  - `@angular/animations` @ "21.1.3" (was "21.1.2")
  - `@angular/cdk` @ "21.1.3" (was "21.1.2")
  - `@angular/common` @ "21.1.3" (was "21.1.2")
  - `@angular/compiler` @ "21.1.3" (was "21.1.2")
  - `@angular/core` @ "21.1.3" (was "21.1.2")
  - `@angular/forms` @ "21.1.3" (was "21.1.2")
  - `@angular/language-service` @ "21.1.3" (was "21.1.2")
  - `@angular/localize` @ "21.1.3" (was "21.1.2")
  - `@angular/platform-browser` @ "21.1.3" (was "21.1.2")
  - `@angular/platform-browser-dynamic` @ "21.1.3" (was "21.1.2")
  - `@angular/router` @ "21.1.3" (was "21.1.2")
  - `@coreui/angular` @ "5.6.12" (was "5.6.10")
  - `@coreui/angular-chartjs` @ "5.6.12" (was "5.6.10")
  - `@coreui/icons-angular` @ "5.6.12" (was "5.6.10")
  - `@types/node` @ "24.10.10" (was "24.10.9")
- chore(dependencies): `@isaacs/brace-expansion` vulnerability https://github.com/advisories/GHSA-7h2j-956f-4vf2
- chore(dependencies): `@modelcontextprotocol/sdk` vulnerability https://github.com/advisories/GHSA-345p-7cg4-v4c7

---

#### `5.6.10`

- chore(dependencies): update to `Angular 21.1.2`
  - `@angular/build` @ "21.1.2" (was "21.1.1")
  - `@angular/cli` @ "21.1.2" (was "21.1.1")
  - `@angular/compiler-cli` @ "21.1.2" (was "21.1.1")
  - `@angular/animations` @ "21.1.2" (was "21.1.1")
  - `@angular/cdk` @ "21.1.2" (was "21.1.1")
  - `@angular/common` @ "21.1.2" (was "21.1.1")
  - `@angular/compiler` @ "21.1.2" (was "21.1.1")
  - `@angular/core` @ "21.1.2" (was "21.1.1")
  - `@angular/forms` @ "21.1.2" (was "21.1.1")
  - `@angular/language-service` @ "21.1.2" (was "21.1.1")
  - `@angular/localize` @ "21.1.2" (was "21.1.1")
  - `@angular/platform-browser` @ "21.1.2" (was "21.1.1")
  - `@angular/platform-browser-dynamic` @ "21.1.2" (was "21.1.1")
  - `@angular/router` @ "21.1.2" (was "21.1.1")
  - `@coreui/angular` @ "5.6.10" (was "5.6.9")
  - `@coreui/angular-chartjs` @ "5.6.10" (was "5.6.9")
  - `@coreui/icons-angular` @ "5.6.10" (was "5.6.9")

- chore(dependencies): jasmine update to v6
  - `@types/jasmine` @ "6.0.0" (was "5.1.15")
  - `jasmine-core` @ "6.0.1" (was "5.13.0")
  - `karma-jasmine-html-reporter` @ "2.2.0" (was "2.1.0")

- chore(dependencies): tar vulnerability https://github.com/advisories/GHSA-r6q2-hw4h-h46w

- chore(prebuild): `ng test --watch=false --browsers=ChromeHeadless`

---

#### `5.6.9`

- chore(dependencies): update to 'Angular 21.1.1' 
  - `@angular/build` @ "21.1.1" (was "21.1.0")
  - `@angular/cli` @ "21.1.1" (was "21.1.0")
  - `@angular/compiler-cli` @ "21.1.1" (was "21.1.0")
  - `@angular/animations` @ "21.1.1" (was "21.1.0")
  - `@angular/cdk` @ "21.1.1" (was "21.1.0")
  - `@angular/common` @ "21.1.1" (was "21.1.0")
  - `@angular/compiler` @ "21.1.1" (was "21.1.0")
  - `@angular/core` @ "21.1.1" (was "21.1.0")
  - `@angular/forms` @ "21.1.1" (was "21.1.0")
  - `@angular/language-service` @ "21.1.1" (was "21.1.0")
  - `@angular/localize` @ "21.1.1" (was "21.1.0")
  - `@angular/platform-browser` @ "21.1.1" (was "21.1.0")
  - `@angular/platform-browser-dynamic` @ "21.1.1" (was "21.1.0")
  - `@angular/router` @ "21.1.1" (was "21.1.0")
  - `@coreui/angular` @ "5.6.9" (was "5.6.8")
  - `@coreui/angular-chartjs` @ "5.6.9" (was "5.6.8")
  - `@coreui/icons-angular` @ "5.6.9" (was "5.6.8")
  - `lodash-es` @ "4.17.23" (was "4.17.22")
- chore(dependencies): tar vulnerability https://github.com/advisories/GHSA-r6q2-hw4h-h46w
- chore(dependencies): lodash vulnerability https://github.com/advisories/GHSA-xxjr-mmjv-4gpg
- chore(dependencies): remove overrides `undici` version to `^7.18.2`
- test(widgets): mock `navigator.language` for Firefox headless compatibility
- fix(widgets): remove non-standard userLanguage and browserLanguage props

---

#### `5.6.8`

- chore(dependencies): update
  - `@coreui/angular` @ "5.6.8" (was "5.6.7")
  - `@coreui/angular-chartjs` @ "5.6.8" (was "5.6.7")
  - `@coreui/icons-angular` @ "5.6.8" (was "5.6.7")

---

#### `5.6.7`

- chore(dependencies): update to 'Angular 21.1'
  - `@angular/build` @ "21.1.0" (was "21.0.5")
  - `@angular/cli` @ "21.1.0" (was "21.0.5")
  - `@angular/compiler-cli` @ "21.1.0" (was "21.0.7")
  - `@angular/animations` @ "21.1.0" (was "21.0.7")
  - `@angular/cdk` @ "21.1.0" (was "21.0.5")
  - `@angular/common` @ "21.1.0" (was "21.0.7")
  - `@angular/compiler` @ "21.1.0" (was "21.0.7")
  - `@angular/core` @ "21.1.0" (was "21.0.7")
  - `@angular/forms` @ "21.1.0" (was "21.0.7")
  - `@angular/language-service` @ "21.1.0" (was "21.0.7")
  - `@angular/localize` @ "21.1.0" (was "21.0.7")
  - `@angular/platform-browser` @ "21.1.0" (was "21.0.7")
  - `@angular/platform-browser-dynamic` @ "21.1.0" (was "21.0.7")
  - `@angular/router` @ "21.1.0" (was "21.0.7")
  - `@coreui/angular` @ "5.6.7" (was "5.6.5")
  - `@coreui/angular-chartjs` @ "5.6.7" (was "5.6.5")
  - `@coreui/icons-angular` @ "5.6.7" (was "5.6.5")
  - `@types/jasmine` @ "5.1.15" (was "5.1.13")
  - `@types/node` @ "24.10.9" (was "24.10.4")
- chore(dependencies): overrides `undici` version to `^7.18.2` to mitigate 2 [low severity vulnerabilities](https://github.com/advisories/GHSA-g9mf-h72j-4rw9)
- chore(dependencies): remove overrides `sass`

---

#### `5.6.5`

- chore(dependencies): update
  - `@angular/build` @ "21.0.5" (was "21.0.4")
  - `@angular/cli` @ "21.0.5" (was "21.0.4")
  - `@angular/compiler-cli` @ "21.0.7" (was "21.0.6")
  - `@angular/animations` @ "21.0.7" (was "21.0.6")
  - `@angular/common` @ "21.0.7" (was "21.0.6")
  - `@angular/compiler` @ "21.0.7" (was "21.0.6")
  - `@angular/core` @ "21.0.7" (was "21.0.6")
  - `@angular/forms` @ "21.0.7" (was "21.0.6")
  - `@angular/language-service` @ "21.0.7" (was "21.0.6")
  - `@angular/localize` @ "21.0.7" (was "21.0.6")
  - `@angular/platform-browser` @ "21.0.7" (was "21.0.6")
  - `@angular/platform-browser-dynamic` @ "21.0.7" (was "21.0.6")
  - `@angular/router` @ "21.0.7" (was "21.0.6")
  - `@coreui/angular` @ "5.6.5" (was "5.6.4")
  - `@coreui/angular-chartjs` @ "5.6.5" (was "5.6.4")
  - `@coreui/icons-angular` @ "5.6.5" (was "5.6.4")

---

#### `5.6.4`

- chore(dependencies): update
  - `@angular/build` @ "21.0.4" (was "21.0.2")
  - `@angular/cli` @ "21.0.4" (was "21.0.2")
  - `@angular/compiler-cli` @ "21.0.6" (was "21.0.3")
  - `@angular/animations` @ "21.0.6" (was "21.0.3")
  - `@angular/cdk` @ "21.0.5" (was "21.0.2")
  - `@angular/common` @ "21.0.6" (was "21.0.3")
  - `@angular/compiler` @ "21.0.6" (was "21.0.3")
  - `@angular/core` @ "21.0.6" (was "21.0.3")
  - `@angular/forms` @ "21.0.6" (was "21.0.3")
  - `@angular/language-service` @ "21.0.6" (was "21.0.3")
  - `@angular/localize` @ "21.0.6" (was "21.0.3")
  - `@angular/platform-browser` @ "21.0.6" (was "21.0.3")
  - `@angular/platform-browser-dynamic` @ "21.0.6" (was "21.0.3")
  - `@angular/router` @ "21.0.6" (was "21.0.3")
  - `@coreui/angular` @ "5.6.4" (was "5.6.0")
  - `@coreui/angular-chartjs` @ "5.6.4" (was "5.6.0")
  - `@coreui/coreui` @ "5.5.0" (was "5.4.3")
  - `@coreui/icons-angular` @ "5.6.4" (was "5.6.0")
  - `lodash-es` @ "4.17.22" (was "4.17.21")
  - `@types/node` @ "24.10.4" (was "24.10.2")
- fix(sass): sass compilation fail - override `sass` version to `^1.97.0` **tempfix**

---

#### `5.6.0`

- chore(dependencies): update to `Angular 21`
  - `@angular/build` @ "21.0.2" (was "20.3.12")
  - `@angular/cli` @ "21.0.2" (was "20.3.12")
  - `@angular/compiler-cli` @ "21.0.3" (was "20.3.14")
  - `@angular/animations` @ "21.0.3" (was "20.3.14")
  - `@angular/cdk` @ "21.0.2" (was "20.2.14")
  - `@angular/common` @ "21.0.3" (was "20.3.14")
  - `@angular/compiler` @ "21.0.3" (was "20.3.14")
  - `@angular/core` @ "21.0.3" (was "20.3.14")
  - `@angular/forms` @ "21.0.3" (was "20.3.14")
  - `@angular/language-service` @ "21.0.3" (was "20.3.14")
  - `@angular/localize` @ "21.0.3" (was "20.3.14")
  - `@angular/platform-browser` @ "21.0.3" (was "20.3.14")
  - `@angular/platform-browser-dynamic` @ "21.0.3" (was "20.3.14")
  - `@angular/router` @ "21.0.3" (was "20.3.14")
  - `@coreui/angular` @ "5.6.0" (was "5.5.24")
  - `@coreui/angular-chartjs` @ "5.6.0" (was "5.5.24")
  - `@coreui/icons-angular` @ "5.6.0" (was "5.5.24")
  - `@types/node` @ "24.10.2" (was "22.19.1")
  - `jasmine-core` @ "5.13.0" (was "5.12.1")
  - `zone.js` @ "0.16.0" (was "0.15.1")
- refactor(breadcrumbs): signal for breadcrumb items
- refactor: remove to zone.js polyfill from prod build
- refactor(app.config): remove `importProvidersFrom(SidebarModule, DropdownModule)`
- refactor: migration from `NgClass` to `class` bindings
- refactor: migration from `NgStyle` to `style` bindings
- fix(colors): colorClasses as Record
- refactor(progress): signals for value and variant prop

---

#### `5.5.24`

- chore(dependencies): update to Angular `20.3.14`
  - `@angular/animations` @ "20.3.14" (was "20.3.3")
  - `@angular/cdk` @ "20.2.14" (was "20.2.7")
  - `@angular/common` @ "20.3.14" (was "20.3.3")
  - `@angular/compiler` @ "20.3.14" (was "20.3.3")
  - `@angular/core` @ "20.3.14" (was "20.3.3")
  - `@angular/forms` @ "20.3.14" (was "20.3.3")
  - `@angular/language-service` @ "20.3.14" (was "20.3.3")
  - `@angular/localize` @ "20.3.14" (was "20.3.3")
  - `@angular/platform-browser` @ "20.3.14" (was "20.3.3")
  - `@angular/platform-browser-dynamic` @ "20.3.14" (was "20.3.3")
  - `@angular/router` @ "20.3.14" (was "20.3.3")
  - `@coreui/angular` @ "5.5.24" (was "5.5.17")
  - `@coreui/angular-chartjs` @ "5.5.24" (was "5.5.17")
  - `@coreui/icons-angular` @ "5.5.24" (was "5.5.17")
  - `chart.js` @ "4.5.1" (was "4.5.0")
  - `@angular/build` @ "20.3.12" (was "20.3.4")
  - `@angular/cli` @ "20.3.12" (was "20.3.4")
  - `@angular/compiler-cli` @ "20.3.14" (was "20.3.3")
  - `@types/jasmine` @ "5.1.13" (was "5.1.9")
  - `@types/node` @ "22.19.1" (was "22.18.8")
  - `jasmine-core` @ "5.12.1" (was "5.11.0")
- refactor(navItems): add otp input pro component docs link

---

#### `5.5.17`
- chore(dependencies): update to Angular `20.3.3`
  - `@angular/build` @ "20.3.4" (was "20.3.2")
  - `@angular/cli` @ "20.3.4" (was "20.3.2")
  - `@angular/compiler-cli` @ "20.3.3" (was "20.3.1")
  - `@angular/animations` @ "20.3.3" (was "20.3.1")
  - `@angular/cdk` @ "20.2.7" (was "20.2.4")
  - `@angular/common` @ "20.3.3" (was "20.3.1")
  - `@angular/compiler` @ "20.3.3" (was "20.3.1")
  - `@angular/core` @ "20.3.3" (was "20.3.1")
  - `@angular/forms` @ "20.3.3" (was "20.3.1")
  - `@angular/language-service` @ "20.3.3" (was "20.3.1")
  - `@angular/localize` @ "20.3.3" (was "20.3.1")
  - `@angular/platform-browser` @ "20.3.3" (was "20.3.1")
  - `@angular/platform-browser-dynamic` @ "20.3.3" (was "20.3.1")
  - `@angular/router` @ "20.3.3" (was "20.3.1")
  - `@coreui/angular` @ "5.5.17" (was "5.5.15")
  - `@coreui/angular-chartjs` @ "5.5.17" (was "5.5.15")
  - `@coreui/icons-angular` @ "5.5.17" (was "5.5.15")
  - `@types/node` @ "22.18.8" (was "22.18.6")
  - `jasmine-core` @ "5.11.0" (was "5.10.0")
  - `typescript` @ "5.9.3" (was "5.9.2")

---

#### `5.5.15`

- chore(dependencies): update to Angular `20.3.1`
  - `@angular/build` @ "20.3.2" (was "20.2.1")
  - `@angular/cli` @ "20.3.2" (was "20.2.1")
  - `@angular/compiler-cli` @ "20.3.1" (was "20.2.2")
  - `@angular/animations` @ "20.3.1" (was "20.2.2")
  - `@angular/cdk` @ "20.2.4" (was "20.2.1")
  - `@angular/common` @ "20.3.1" (was "20.2.2")
  - `@angular/compiler` @ "20.3.1" (was "20.2.2")
  - `@angular/core` @ "20.3.1" (was "20.2.2")
  - `@angular/forms` @ "20.3.1" (was "20.2.2")
  - `@angular/language-service` @ "20.3.1" (was "20.2.2")
  - `@angular/localize` @ "20.3.1" (was "20.2.2")
  - `@angular/platform-browser` @ "20.3.1" (was "20.2.2")
  - `@angular/platform-browser-dynamic` @ "20.3.1" (was "20.2.2")
  - `@angular/router` @ "20.3.1" (was "20.2.2")
  - `@coreui/angular` @ "5.5.15" (was "5.5.11")
  - `@coreui/angular-chartjs` @ "5.5.15" (was "5.5.11")
  - `@coreui/coreui` @ "5.4.3" (was "5.4.2")
  - `@coreui/icons-angular` @ "5.5.15" (was "5.5.11")
  - `@types/node` @ "22.18.6" (was "22.18.0")
  - `jasmine-core` @ "5.10.0" (was "5.9.0")
  - `typescript` @ "5.9.2" (was "5.8.3")
- refactor(navItems): add autocomplete pro component docs link

---

#### `5.5.11`

- chore(dependencies): update to Angular `20.2.2`

  - @angular/build @ "20.2.1" (was "20.1.6")
  - @angular/cli @ "20.2.1" (was "20.1.6")
  - @angular/compiler-cli @ "20.2.2" (was "20.1.7")
  - @types/node @ "22.18.0" (was "22.17.2")
  - @angular/animations @ "20.2.2" (was "20.1.7")
  - @angular/cdk @ "20.2.1" (was "20.1.6")
  - @angular/common @ "20.2.2" (was "20.1.7")
  - @angular/compiler @ "20.2.2" (was "20.1.7")
  - @angular/core @ "20.2.2" (was "20.1.7")
  - @angular/forms @ "20.2.2" (was "20.1.7")
  - @angular/language-service @ "20.2.2" (was "20.1.7")
  - @angular/localize @ "20.2.2" (was "20.1.7")
  - @angular/platform-browser @ "20.2.2" (was "20.1.7")
  - @angular/platform-browser-dynamic @ "20.2.2" (was "20.1.7")
  - @angular/router @ "20.2.2" (was "20.1.7")
  - @coreui/angular @ "5.5.11" (was "5.5.8")
  - @coreui/angular-chartjs @ "5.5.11" (was "5.5.8")
  - @coreui/icons-angular @ "5.5.11" (was "5.5.8")

---

#### `5.5.8`

- chore(dependencies): update
  - @angular/build @ "20.1.6" (was "20.1.0")
  - @angular/cli @ "20.1.6" (was "20.1.0")
  - @angular/compiler-cli @ "20.1.7" (was "20.1.0")
  - @angular/animations @ "20.1.7" (was "20.1.0")
  - @angular/cdk @ "20.1.6" (was "20.1.0")
  - @angular/common @ "20.1.7" (was "20.1.0")
  - @angular/compiler @ "20.1.7" (was "20.1.0")
  - @angular/core @ "20.1.7" (was "20.1.0")
  - @angular/forms @ "20.1.7" (was "20.1.0")
  - @angular/language-service @ "20.1.7" (was "20.1.0")
  - @angular/localize @ "20.1.7" (was "20.1.0")
  - @angular/platform-browser @ "20.1.7" (was "20.1.0")
  - @angular/platform-browser-dynamic @ "20.1.7" (was "20.1.0")
  - @angular/router @ "20.1.7" (was "20.1.0")
  - @coreui/angular @ "5.5.8" (was "5.5.5")
  - @coreui/angular-chartjs @ "5.5.8" (was "5.5.5")
  - @coreui/coreui @ "5.4.2" (was "5.4.1")
  - @coreui/icons-angular @ "5.5.8" (was "5.5.5")
  - @types/jasmine @ "5.1.9" (was "5.1.8")
  - @types/node @ "22.17.2" (was "22.16.3")
  - jasmine-core @ "5.9.0" (was "5.8.0")
- test: drop deprecated BrowserDynamicTestingModule, use BrowserTestingModule and platformBrowserTesting()

---

#### `5.5.5`

- chore(dependencies): update to `Angular 20.1`

---

#### `5.5.3`

- chore(dependencies): update
- chore: add docs-components and docs-icons, minor cleanups
- refactor(navItems): add pro components docs links

---

#### `5.5.1`

- chore(dependencies): update to `Angular 20`
  - update `@angular/*` to `^20.0.x`
  - update `typescript` to `~5.8.3`
  - move `@angular/localize` to `dependencies` for use at runtime
  - update `@coreui/angular` to `~5.5.1`
  - update `@coreui/angular-chartjs` to `~5.5.1`
  - update `@coreui/icons-angular` to `~5.5.1`
  - update `moduleResolution` to `bundler` in TypeScript configurations
  - migrate application project to the new build system with `application` builder
  - update imports of `DOCUMENT` from `@angular/common` to `@angular/core`
  - update Node.js version list to the supported versions
  
- fix(dashboard): `TS2307`: Cannot find module `chart.js/dist/types/utils` or its corresponding type declarations. `[plugin angular-compiler]` - tempfix
- refactor: migrate to `inject` function (remove constructor-based dependency injection)
- refactor(toasters): use ComponentRef `setInput()` api
- refactor: migration to signal inputs, host bindings, cleanups
- refactor: migration to signal queries
- fix(mainChart): chart.js - Cannot read properties of undefined _clip (reading 'disabled')  - fixed by stop() current animations
- test: remove deprecated RouterTestingModule, use provideRouter() instead
- refactor: migration to lazy-loaded routes
- refactor: migration to self-closing tags

---

#### `5.4.6`

- chore(dependencies): update
- fix(pages): obsolete css class used in login page example, closes #279 - thanks @bernik1980

---

#### `5.4.5`

- chore(dependencies): update
- fix(default-layout): missing min-height for .ng-scroll-content

---

#### `5.4.3`

- chore(dependencies): update to `Angular 19.2`

---

#### `5.4.1`

- chore(dependencies): version bump for tilde `~` dependencies for @coreui/* to avoid Sass modules mismatch

---

#### `5.4.0`

- **refactor(styles): migrate to Sass modules, cleanup**
- refactor(default-layout): scrollbar cleanups
- chore(dependencies): update
- refactor(carousels): toggle interval example
- refactor(form-control): cleanup readonly / plaintext example
- fix(icon-subset): typo in cilContrast
- refactor(dropdowns): disabled cDropdownItem example
- fix(docs-example): set routerLink="" for Preview nav-item

---

#### `5.3.9`

- chore(dependencies): update
- refactor(carousels): cleanup, add config
- refactor(app.config): use provideAnimationAsync
- chore(modals): remove @.disabled animations

---

#### `5.3.8`

- chore(dependencies): update to `Angular 19.1`
- fix(toast): narrow type for cToastClose

---

#### `5.3.4`

- chore(dependencies): update
- chore(dependencies): security patch for `path-to-regexp` ReDoS in 0.1.x
- fix(toast.component): remove constructor-based dependency injection

---

#### `5.3.3`

- chore(dependencies): update
- chore(workflows): update node-version to 22.x

---

#### `5.3.2`

- chore(dependencies): update 
- chore(workflows): update with npm ci
- fix(package-lock): rebuild

---

#### `5.3.1`
 
- chore(dependencies): update to Angular 19
- refactor: directives, components and pipes are now standalone by default
- fix(dashboard-charts-data): brandInfoBg rgb is not a valid hex color
- chore(build): silence sass import deprecation warnings
- fix(toasters): remove position from props for AppToastComponent

---

#### `5.2.22`

- chore(dependencies): update to `Angular 18.2.9`
- fix(widgets-brand): use capBg instead of color
- fix(toasters): toast.index is a signal

---

#### `5.2.16`

- chore(dependencies): update
  - `tslib` to `^2.7.0`
  - `micromatch` to `4.0.8`
    - see vulnerability [Regular Expression Denial of Service (ReDoS) in micromatch](https://github.com/advisories/GHSA-952p-6rrq-rcjv)

---

#### `5.2.15`

- chore(dependencies): update to `Angular 18.2`
- refactor: move ColorModeService setup from default-header to app component
- chore(karma.conf): add custom chrome launcher with `--disable-search-engine-choice-screen` flag

---

#### `5.2.5`

- chore(dependencies): update to `Angular 18.1`
- refactor(cards): card navigation update to the latest `tabs` api

---

#### `5.2.3`

- chore(dependencies): update
- fix(widgets): c-progress white with inverse()

---

#### `5.2.0`

- chore(dependencies): update to Angular 18
- refactor(tabs): update to the latest api

---

#### `5.0.4`

- chore(dependencies): update

---

#### `5.0.3`

- chore(dependencies): update
- fix: add missing `aria-label` attributes etc
- refactor(tabs): add `role="tablist"`, minor cleanups

---

#### `5.0.2`

- chore(dependencies): update
- refactor(default-header): color modes dropdown

---

#### `5.0.0`

CoreUI v5 for Angular 17

- chore(dependencies): update to `Angular 17.3`
- refactor: update to CoreUI v5 (styles, structure, api)
- refactor: standalone components app
- refactor: routes config
- refactor: update to chart.js v4
- refactor: project structure (containers->layout)
- refactor: use control flow
- refactor(dashboard): main chart data - typings and theme switching fix
- fix(dashboard): missing custom tooltips on first render, refactor main chart scales

---

#### `4.7.15`

- chore: move to `application` builder
- chore(dependencies): update to `Angular 17.2`
    - `Angular 17.2`
    - `TypeScript ~5.3`
    - `zone.js ~0.14.4`
    - `@coreui/angular ~4.7.15`
    - `@coreui/angular-chartjs ~4.7.14`
    - `@coreui/icons-angular ~4.7.14`

---

#### `4.7.13`

- chore(dependencies): update to `Angular 17.1`
    - `Angular 17.1`
    - `TypeScript ~5.2`
    - `zone.js ~0.14.3`
    - `@coreui/angular ~4.7.13`
    - `@coreui/angular-chartjs ~4.7.13`
    - `@coreui/icons-angular ~4.7.13`

---

#### `4.7.0`

- chore(dependencies): update to `Angular 17`
    - `Angular 17`
    - `TypeScript ~5.2`
    - `zone.js ~0.14.2`
    - `@coreui/angular ~4.7.0`
    - `@coreui/angular-chartjs ~4.7.0`
    - `@coreui/icons-angular ~4.7.0`

```shell
ng update @angular/core@17 @angular/cli@17 @angular/cdk@17 @coreui/angular@~4.7 @coreui/angular-chartjs@~4.7 @coreui/icons-angular@~4.7

```

---

#### `4.5.28`

- chore(dependencies): update

---

#### `4.5.27`

- chore(dependencies): update

see: [Babel vulnerable to arbitrary code execution when compiling specifically crafted malicious code](https://github.com/coreui/coreui-angular/security/dependabot/31)

---

#### `4.5.25`

- chore(dependencies): update

---

#### `4.5.16`

- chore(dependencies): update to `Angular 16.2`
- fix(carousels): remove routerLink directives from carousel controls
- chore: add CoreUI links to the sidebar-nav, minor refactors
- refactor(styles): scrollbar tweaks
- refactor(styles): scss variables - disable deprecation messages

---

#### `4.5.2`

- chore(dependencies): update to `Angular 16.1`

---

#### `4.5.0`

- chore(dependencies): update to `Angular 16`
- refactor: remove deprecated ngx-perfect-scrollbar, use `ngx-scrollbar` instead
- fix: getStyle() add nullish check
- refactor(toasters): use takeUntilDestroyed() operator

---

#### `4.3.13`

- docs(LICENSE): add missing license info
- chore(dependencies): update

---

#### `4.3.12`

- chore(dependencies): update

---

#### `4.3.11`

- chore(dependencies): update `@angular/*` to version `^15.2.7`
- standalone components:
    - chore(dependencies): update `@coreui/angular` to version `~4.4.1`
    - chore(dependencies): update `@coreui/angular-chartjs` to version `~4.4.1`
    - chore(dependencies): update `@coreui/icons-angular` to version `~4.4.1`
- fix(widgets): breakpoints

---

#### `4.3.10`

- chore(dependencies): update `@angular/*` to version `^15.2.4`
- chore(dependencies): update `@coreui/angular` to version `~4.3.17`
- chore(dependencies): update `@coreui/angular-chartjs` to version `~4.3.17`
- chore(dependencies): update `@coreui/icons-angular` to version `~4.3.17`
- chore(dependencies): update `@coreui/icons` to version `^3.0.1`
- chore(dependencies): update `@coreui/charts` to version `^3.1.1`
- chore(dependencies): update `@coreui/utils` to version `^2.0.1`

imports update required :boom: :exclamation:

- from `import {getStyle, ...} from '@coreui/utils/src`
- to `import {getStyle, ...} from '@coreui/utils`

---

#### `4.3.9`

- chore: dependencies update
- fix(widgets): add missing pointBackgroundColor

---

#### `4.3.0`

update to:

- `Angular 15`
- `TypeScript 4.8`
- `RxJS 7.5`

refactor:

- refactor(AppComponent): change selector to `app-root`

---
